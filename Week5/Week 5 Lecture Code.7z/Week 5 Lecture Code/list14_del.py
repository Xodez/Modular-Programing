trees = [ "oak", "birch", "beech", "maple" ]
print(trees)
del trees[3]

print(trees)
del trees[0:2]

print(trees)
del trees[:]

print(trees)

