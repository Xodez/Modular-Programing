#   Name: basic list access
#   Author: Helen Fagan
numbers = [6,19,23,14 ]
print ("Number at index 0 is " + str(numbers[0]))
print ("Number at index 1 is " + str(numbers[1]))
print ("Number at index -1 is " + str(numbers[-1]))
print (numbers)
