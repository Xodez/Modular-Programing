def get_hours_worked(number_of_employees):

     ## TODO ask the user to enter hours for
     ## number_of_employees
     hours_worked = [32, 45, 25, 43, ]
     return hours_worked


def show_hours_per_employee(hours_worked):
    print("show hours")


def get_total_pay(hours_worked, hourly_pay_rate):
    return 0


def get_min_hours(hours_worked):
    return 0


def get_average_pay(hours_worked):
    return 0


def get_bonus_money_needed(hours_worked):
    return 0


def main():
    # to do get the following from teh user
    num_employees = 4
    hours_worked = get_hours_worked(num_employees)
    num_employees = len(hours_worked)
    # modify later to get from teh user
    hourly_pay_rate = 22.00
    print("complete the methods")


main()