import reading_from_user

number = reading_from_user.read_integer("Please give a number ")