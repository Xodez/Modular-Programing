from reading_from_user import read_integer

number = read_integer("Please give a number ")